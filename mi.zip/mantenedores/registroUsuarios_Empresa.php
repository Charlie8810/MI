<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="insidehead">
    <link rel="shortcut icon" href="assets/images/favicon.png">
    <title>MI - MCM Interactive Learning</title>
    <?php include("../matrices/css.php");?>
    <script src="../assets/js/modernizr.min.js"></script>
    <script type="text/javascript" src="js/jquery-1.3.2.min.js"></script>
</head>
<body class="fixed-left">
    <!-- Begin page -->
    <div id="wrapper">
        <!-- Top Bar Start -->
        
        <?php include("../matrices/topbaradministrador.php");?>

        <!-- Top Bar End -->
        <!-- ========== Left Sidebar Start ========== -->
        
        <?php include("../matrices/left-side-menu.php");?>

        <!-- Left Sidebar End -->
        <!-- ============================================================== -->
        <!-- Start right Content here -->
        <!-- ============================================================== -->
        <div class="content-page">
            <!-- Start content -->
            <div class="content">
                <div class="container">
                    <!-- Page-Title -->
                    <div class="row">
                        <div class="col-sm-12">
                            <h4 class="page-title">
                                Registro de Usuarios</h4>
                            <ol class="breadcrumb">
                                <li><a href="/mi/Nivel_1.php">Inicio</a></li>
                                <li><a href="/mi/mantenedores/registroUsuarios.php">Gestor de Usuarios</a></li>
                                <li class="active">Registro de Usuarios</li>
                            </ol>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-6">
                            <div class="card-box">
                                <h4 class="m-t-0 header-title">
                                    <b>Datos a Ingresar</b></h4>
                                <form action="#" data-parsley-validate novalidate>
                                <div class="form-group">
                                    <label for="userName">
                                        Nombre / Razón Social*</label>
                                    <input type="text" name="nick" parsley-trigger="change" required placeholder="Ingresar Nombre / Razón Social"
                                        class="form-control" id="userName">
                                </div>
                                <div class="form-group">
                                    <label for="userName">
                                        RUT*</label>
                                    <input type="text" name="nick" parsley-trigger="change" required placeholder="Ingresar RUT"
                                        class="form-control" id="Text4">
                                </div>

                                <div class="form-group">
                                    <label for="userName">
                                        Dirección*</label>
                                    <input type="text" name="nick" parsley-trigger="change" required placeholder="Ingresar Dirección"
                                        class="form-control" id="Text1">
                                </div>

                                <script type="text/javascript">
$(document).ready(function(){
    cargar_regiones();
    $("#region").change(function(){dependencia_comuna();});
    //$("#comuna").change(function(){dependencia_comuna();});
    $("#comuna").attr("disabled",true);
    //$("#ciudad").attr("disabled",true);
});

function cargar_regiones()
{
    $.get("scripts/cargar-regiones.php", function(resultado){
        if(resultado == false)
        {
            alert("Error");
        }
        else
        {
            $('#region').append(resultado);           
        }
    }); 
}
function dependencia_comuna()
{
    var code = $("#region").val();
    $.get("scripts/dependencia-comuna.php", { code: code },
        function(resultado)
        {
            if(resultado == false)
            {
                alert("Error");
            }
            else
            {
                $("#comuna").attr("disabled",false);
                document.getElementById("comuna").options.length=1;
                $('#comuna').append(resultado);         
            }
        }

    );
}
</script>
                                <div class="form-group">
                                    <label for="userName">
                                        Región*</label>
                                    <select class="selectpicker  form-control" data-style="btn-white" id="region" name="region">
                                       
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label for="userName">
                                        Comuna*</label>
                                    <select class="selectpicker  form-control" data-style="btn-white"  id="comuna" name="comuna">
                                        
                                    </select>
                                </div>


                                <div class="form-group">
                                    <label for="userName">
                                        Nombre de Contacto*</label>
                                    <input type="text" name="nick" parsley-trigger="change" required placeholder="Ingresar Nombre de Contacto"
                                        class="form-control" id="Text3">
                                </div>
                                <div class="form-group">
                                    <label for="emailAddress">
                                        Email de Contacto*</label>
                                    <input type="email" name="email" parsley-trigger="change" required placeholder="Ingresar Email  de Contacto"
                                        class="form-control" id="emailAddress">
                                </div>
                                <div class="form-group">
                                    <label for="emailAddress">
                                        Teléfono de Contacto*</label>
                                    <input type="email" name="email" parsley-trigger="change" required placeholder="Ingresar Teléfono  de Contacto"
                                        class="form-control" id="email1">
                                </div>
                                <div class="form-group text-right m-b-0">
                                    <button class="btn btn-primary waves-effect waves-light" type="submit">
                                        Guardar
                                    </button>
                                    <button type="reset" class="btn btn-default waves-effect waves-light m-l-5">
                                        Cancelar
                                    </button>
                                </div>
                                </form>
                            </div>
                        </div>
                        
                    </div>
                </div>
                <!-- container -->
            </div>
            <!-- content -->
            <?php include("../matrices/footer.php");?>
        </div>
        <!-- ============================================================== -->
        <!-- End Right content here -->
        <!-- ============================================================== -->
        <!-- Right Sidebar -->
        <div class="side-bar right-bar nicescroll">
            <h4 class="text-center">
                Chat</h4>
            <div class="contact-list nicescroll">
                <ul class="list-group contacts-list">
                    <li class="list-group-item"><a href="#">
                        <div class="avatar">
                            <img src="assets/images/users/avatar-1.jpg" alt="">
                        </div>
                        <span class="name">Chadengle</span> <i class="fa fa-circle online"></i></a><span
                            class="clearfix"></span></li>
                    <li class="list-group-item"><a href="#">
                        <div class="avatar">
                            <img src="assets/images/users/avatar-2.jpg" alt="">
                        </div>
                        <span class="name">Tomaslau</span> <i class="fa fa-circle online"></i></a><span class="clearfix">
                        </span></li>
                    <li class="list-group-item"><a href="#">
                        <div class="avatar">
                            <img src="assets/images/users/avatar-3.jpg" alt="">
                        </div>
                        <span class="name">Stillnotdavid</span> <i class="fa fa-circle online"></i></a><span
                            class="clearfix"></span></li>
                    <li class="list-group-item"><a href="#">
                        <div class="avatar">
                            <img src="assets/images/users/avatar-4.jpg" alt="">
                        </div>
                        <span class="name">Kurafire</span> <i class="fa fa-circle online"></i></a><span class="clearfix">
                        </span></li>
                    <li class="list-group-item"><a href="#">
                        <div class="avatar">
                            <img src="assets/images/users/avatar-5.jpg" alt="">
                        </div>
                        <span class="name">Shahedk</span> <i class="fa fa-circle away"></i></a><span class="clearfix">
                        </span></li>
                    <li class="list-group-item"><a href="#">
                        <div class="avatar">
                            <img src="assets/images/users/avatar-6.jpg" alt="">
                        </div>
                        <span class="name">Adhamdannaway</span> <i class="fa fa-circle away"></i></a><span
                            class="clearfix"></span></li>
                    <li class="list-group-item"><a href="#">
                        <div class="avatar">
                            <img src="assets/images/users/avatar-7.jpg" alt="">
                        </div>
                        <span class="name">Ok</span> <i class="fa fa-circle away"></i></a><span class="clearfix">
                        </span></li>
                    <li class="list-group-item"><a href="#">
                        <div class="avatar">
                            <img src="assets/images/users/avatar-8.jpg" alt="">
                        </div>
                        <span class="name">Arashasghari</span> <i class="fa fa-circle offline"></i></a><span
                            class="clearfix"></span></li>
                    <li class="list-group-item"><a href="#">
                        <div class="avatar">
                            <img src="assets/images/users/avatar-9.jpg" alt="">
                        </div>
                        <span class="name">Joshaustin</span> <i class="fa fa-circle offline"></i></a><span
                            class="clearfix"></span></li>
                    <li class="list-group-item"><a href="#">
                        <div class="avatar">
                            <img src="assets/images/users/avatar-10.jpg" alt="">
                        </div>
                        <span class="name">Sortino</span> <i class="fa fa-circle offline"></i></a><span class="clearfix">
                        </span></li>
                </ul>
            </div>
        </div>
        <!-- /Right-bar -->
    </div>
    <!-- END wrapper -->
    <script>
        var resizefunc = [];
    </script>
    <!-- jQuery  -->
    <?php include("../matrices/js.php");?>
    <script type="text/javascript">
        $(document).ready(function () {
            $('form').parsley();
        });
    </script>				<!-- Google Analytics -->		<script>		  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){		  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),		  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)		  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');		  ga('create', 'UA-74180346-1', 'auto');		  ga('send', 'pageview');		</script>		<!-- //Google Analytics -->		
</body>
</html>
