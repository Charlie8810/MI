<footer class="footer">
   <b> <?php echo date("Y"); ?> &copy; MI - MCM Interactive Learning </b>| <span style="font-size:10px">developed by <a href="http://www.insidehead.cl" target="_blank" style="color:#f6a200;font-weight: bold;" title="insidehead > diseñoMKTpublicidadDESARROLLOinvestigaciónFOTOGRAFIA">insidehead</a></span>
</footer>