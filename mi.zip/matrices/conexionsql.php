<?php

// Conectando, seleccionando la base de datos

$link = mysql_connect('190.107.177.242', 'cin1770_cleales', 'Camilo1991');
mysql_select_db('cin1770_sca');

?>