<?php
	function Conectarse()
	{
   		if (!($link=mysql_connect("190.107.177.242", "cin1770_cleales", "Camilo1991")))
   	{
    	echo "Error conectando a la base de datos.";
     	exit();
   	}
   		if (!mysql_select_db("cin1770_sca",$link))
   	{
		echo "Error seleccionando la base de datos.";
      	exit();
   	}
   		return $link;
	}

	$link=Conectarse();
	echo "Conexión con la base de datos conseguida.<br>";

	mysql_close($link);
?>
